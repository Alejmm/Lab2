// src/app/services/api.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

const API_BASE_URL = 'http://localhost:5122/api'; // ajusta puerto si aplica

export interface Person { id: number; firstName: string; lastName: string; email: string; }

@Injectable({ providedIn: 'root' })
export class ApiService {
  constructor(private http: HttpClient) {}
  getPersons(): Observable<Person[]> {
    return this.http.get<Person[]>(`${API_BASE_URL}/Person`);
  }
}
