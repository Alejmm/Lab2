import { Component } from '@angular/core';

@Component({
  selector: 'app-order-list',
  imports: [],
  templateUrl: './order-list.html',
  styleUrl: './order-list.css'
})
export class OrderList {

}
