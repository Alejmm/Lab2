import { Component } from '@angular/core';

@Component({
  selector: 'app-item-form',
  imports: [],
  templateUrl: './item-form.html',
  styleUrl: './item-form.css'
})
export class ItemForm {

}
