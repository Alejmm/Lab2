import { Component } from '@angular/core';

@Component({
  selector: 'app-person-form',
  imports: [],
  templateUrl: './person-form.html',
  styleUrl: './person-form.css'
})
export class PersonForm {

}
