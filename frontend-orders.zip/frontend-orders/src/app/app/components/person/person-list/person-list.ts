// src/app/components/person/person-list/person-list.ts
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService, Person } from '../../../services/api';

@Component({
  selector: 'app-person-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './person-list.html',
  styleUrl: './person-list.css'
})
export class PersonListComponent implements OnInit {
  persons: Person[] = [];
  loading = true;
  error = '';

  constructor(private api: ApiService) {}

  ngOnInit(): void {
    this.api.getPersons().subscribe({
      next: d => { this.persons = d; this.loading = false; },
      error: e => { this.error = 'No se pudo cargar Personas'; this.loading = false; console.error(e); }
    });
  }
}
