// src/app/app.routes.ts
import { Routes } from '@angular/router';
import { PersonListComponent } from './components/person/person-list/person-list'; 

export const routes: Routes = [
  { path: '', redirectTo: 'persons', pathMatch: 'full' },
  { path: 'persons', component: PersonListComponent }
];
