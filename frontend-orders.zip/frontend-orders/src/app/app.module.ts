import { HttpClientModule } from '@angular/common/http';

@NgModule({
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule   // <- debe estar aquí
  ],
  // ...
})
export class AppModule {}
